## 音乐播放器

### 1. 如何运行
1. npm i // 安装依赖
2. npm run serve // 运行web
3. npm run mock // 运行server
4. 访问 http://localhost:8080

### 所需要播放的mp3文件放在music目录即可